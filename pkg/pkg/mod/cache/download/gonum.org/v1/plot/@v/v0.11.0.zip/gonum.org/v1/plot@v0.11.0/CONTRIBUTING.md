See the [gonum project-wide CONTRIBUTING.md file.](https://github.com/gonum/gonum/blob/master/CONTRIBUTING.md)
